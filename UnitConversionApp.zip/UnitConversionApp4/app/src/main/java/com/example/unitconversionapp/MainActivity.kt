package com.example.unitconversionapp

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val inputValue: EditText = findViewById(R.id.inputValue)
        val unitSpinner: Spinner = findViewById(R.id.unitSpinner)
        val convertButton: Button = findViewById(R.id.convertButton)
        val outputValue: TextView = findViewById(R.id.outputValue)

        // Populate the Spinner with unit options
        val adapter = ArrayAdapter.createFromResource(
            this,
            R.array.units_array, android.R.layout.simple_spinner_item
        )
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        unitSpinner.adapter = adapter

        // Handle the conversion logic
        convertButton.setOnClickListener {
            val input = inputValue.text.toString()
            val selectedUnit = unitSpinner.selectedItem.toString()
            if (input.isNotEmpty()) {
                val value = input.toDouble()
                val convertedValue = convertUnits(value, selectedUnit)
                outputValue.text = "Converted Value: $convertedValue"
            }
        }
    }

    private fun convertUnits(value: Double, unit: String): Double {
        return when (unit) {
            "Centimeters to Meters" -> value / 100
            "Grams to Kilograms" -> value / 1000
            else -> value
        }
    }
}